 <div class="footer">
     <div class="footerTop">

         <div class="row">

             <div class="large-3 medium-6 small-12 columns footer-widget">
                 <h2>About Us</h2>
                 <div class="tx-div"></div>
                 <p>We are very proud to announce that since 1986 we are spreading awesomness to our community
                     and we have helped a lot people to shape their better future and life! I hope we are doing
                     best we can. If you have any kind of questions please call or contact us.</p>
             </div><!-- Widget 1 ends /-->

             <div class="large-3 medium-6 small-12 columns footer-widget quick-links">
                 <h2>Quick Links</h2>
                 <div class="tx-div"></div>
                 <ul class="menu vertical">
                     <li><a href="courses.html">Admissions</a></li>
                     <li><a href="courses.html">Courses</a></li>
                     <li><a href="courses.html">Contact Admin</a></li>
                     <li><a href="courses.html">Teachers</a></li>
                     <li><a href="courses.html">College Life</a></li>
                     <li><a href="courses.html">Upcoming Events</a></li>
                 </ul>
                 <ul class="menu vertical">
                     <li><a href="courses.html">Students</a></li>
                     <li><a href="courses.html">College</a></li>
                     <li><a href="courses.html">Transport</a></li>
                     <li><a href="courses.html">Principle</a></li>
                     <li><a href="courses.html">Policy</a></li>
                     <li><a href="courses.html">Terms & Conditions</a></li>
                 </ul>
             </div><!-- Widget 2 Ends /-->

             <div class="large-3 medium-6 small-12 columns footer-widget">
                 <h2>Institute Hours</h2>
                 <div class="tx-div"></div>
                 <ul class="vertical office-hours">
                     <li>Monday: 09:00 - 17:00 </li>
                     <li>Tuseday: 09:00 - 17:00</li>
                     <li>Wednesday: 09:00 - 17:00</li>
                     <li>Thursday: 09:00 - 17:00</li>
                     <li>Friday: 09:00 - 17:00</li>
                     <li>Saturday, Sunday: No Admission/Enquiry</li>
                 </ul>
             </div><!-- Widget 3 Ends /-->

             <div class="large-3 medium-6 small-12 columns footer-widget">
                 <div class="textwidget">
                     <ul class="address">
                         <li>
                             <i class="fa fa-home"></i>
                             <h4>Address:</h4>
                             <p>132 Jefferson Avenue, Suite 22,
                                 Redwood City, CA 94872, USA</p>
                         </li>
                         <li>
                             <i class="fa fa-mobile"></i>
                             <h4>Phone:</h4>
                             <p>(00) 123 456 789</p>
                         </li>
                         <li>
                             <i class="fa fa-envelope"></i>
                             <h4>Email:</h4>
                             <p>Name@gmail.com</p>
                         </li>
                     </ul>
                     <hr>
                     <div class="socialicons">
                         Social:
                         <a href="#"><i class="fa fa-facebook"></i></a>
                         <a href="#"><i class="fa fa-twitter"></i></a>
                         <a href="#"><i class="fa fa-google"></i></a>
                     </div><!-- Social Icons /-->
                 </div><!-- text widget /-->
             </div><!-- widget 4 /-->
             <div class="clearfix"></div>

         </div><!-- Row Ends /-->

     </div><!-- footerTop Ends here.. -->

     <div class="footerbottom">

         <div class="row">

             <div class="medium-6 small-12 columns">
                 <div class="copyrightinfo">2016 &copy; <a href="#">Webful Creations Vision</a> All Rights
                     Reserved.</div>
             </div><!-- left side /-->
             <div class="medium-6 small-12 columns hide-for-small-only">
                 <div class="pull-right">
                     <ul class="menu">
                         <li><a href="index-2.html">Home</a></li>
                         <li><a href="about-us.html">About</a></li>
                         <li><a href="blog1.html">News</a></li>
                         <li><a href="services.html">Services</a></li>
                         <li><a href="contact.html">Contact Us</a></li>
                     </ul>
                 </div>
             </div><!-- Right Side /-->

         </div><!-- Row /-->

     </div><!-- footer Bottom /-->
 </div>