<?php $__env->startSection('title','NEXTGEN'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>





<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Dashboard</h2>
        </div>
    </div>




    

<?php $__env->stopSection(); ?>








<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/backend/js/charts-home.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nextzen\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>