<?php $__env->startSection('title','NEXTGEN(Slider-view)'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>





<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="container-fluid">
        <h2 class="h5 no-margin-bottom">Slider View</h2>
    </div>
</div>


<div id='pw_view'>
<div class="row mt-3" style="margin-left:90px">

    <?php $__currentLoopData = $processWorkflows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $processWorkflow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4" >
    <div class="card" style="width: 18rem;">

        <div class="card-body">
            <center><h4><?php echo e($processWorkflow->header); ?></h4></center>
            <p class="card-text"><?php echo e($processWorkflow->text); ?></p>
            
            <center>
            <div class="btn-group btn-group-toggle" data-toggle="buttons">
            
                <button type='button' class="badge badge-danger" onclick='deletePwAjax(<?php echo e($processWorkflow->id); ?>)'><i
                        class="fa fa-trash"></i></button>

                <button  type='button' class="badge badge-info ml-3" onclick="processWorkflowEdit(<?php echo e($processWorkflow->id); ?>,'#image<?php echo e($loop->iteration); ?>')" ><i data-icon="u"></i></button>
            
            </div>
           </center>
        </div>
    </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>
</div>


<!-- Modal -->
<div class="modal fade" id="process-workflow-edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Process Workflow Edit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
             
             <form id='processWorkflowUpdate'>
                 <?php echo csrf_field(); ?>
                 <input type="hidden" class="form-control" id="pw_id" name='pw_id'>
                 <div class="form-group">
                     <label for="exampleInputEmail1">Header - </label>
                     <input type="text" class="form-control" id="header" name='header'>
                     
                 </div>

                 <div class="form-group">
                        <label class="form-control-label">Text</label>
                        <textarea class="form-control" id="text" rows="3" style="resize: none;" name='text'></textarea>
                    </div>
                 
            </div>
            <div class="modal-footer">

                <button type="button" class="btn btn-primary" onclick="updateProcessWorkflow()">Save changes</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

                </form> 
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>


function processWorkflowEdit(pwfId){

                $.ajax({
                        type: 'post',
                        url: '<?php echo e(URL::TO("processWorkflowEditAjax")); ?>',
                        data:"&_token=<?php echo e(csrf_token()); ?>"+"&pwfId="+pwfId,
                        dataType: 'json',
                        success: function (data) {
                        //    console.log(data);
                             $('#pw_id').val(pwfId);
                             $('#header').val(data.pWinfo.header);
                             $('#text').val(data.pWinfo.text);
                             $('#process-workflow-edit').modal({show:true});

                        },
                        error: function (data) {

                        }

                    });
            }


function updateProcessWorkflow(){
        var formData = $('#processWorkflowUpdate').serialize();
            $.ajax({
                type: 'post',
                url: '<?php echo e(URL::TO("processWorkflowUpdateAjax")); ?>',
                data: formData,
                dataType: 'json',
                success: function (data) {
                    if (typeof data.errors !== 'undefined') {
                        swal({
                            title: "please input properly!",
                            text: "Enter The Value",
                            type: "warning"
                        });

                          $('#process-workflow-edit').modal('hide');
                    }else {
                         $('#process-workflow-edit').modal('hide');
                        swal(data, "Data Saved!", "success")
                        clearForm('#addProcessWorkflowForm');
                        $("#pw_view").load(location.href + " #pw_view");
                    }
                },
                error: function (data) {

                }
            });

}



function deletePwAjax(id){

      event.preventDefault();
      swal({
      title: "Are you sure?",
      text: "To Delete this!",
      type: "warning",
      showCancelButton: true,
      confirmButtonClass: "btn-primary",
      confirmButtonText: "Yes",
      cancelButtonClass:"btn-danger",
      cancelButtonText: "Cancel",
      closeOnConfirm: false,
      closeOnCancel: false,
      showLoaderOnConfirm: true
      },
      function(isConfirm) {
      if (isConfirm) {

          $.ajax({
                type: 'post',
                url: '<?php echo e(URL::TO("processWorkflowDeleteAjax")); ?>',
                data:"_token=<?php echo e(csrf_token()); ?>"+"&id="+id,
                dataType: 'json',
                success: function (data) {
                    if (typeof data.errors !== 'undefined') {
                        swal({
                            title: data,
                            text: "Enter The Value",
                            type: "warning"
                        });
                    } else {
                        swal(data, "Data Deleted!", "success")
                        $("#pw_view").load(location.href + " #pw_view");
                    }
                },
                error: function (data) {
                    
                }

            });

      } else {
      swal("Cancelled", "Your imaginary file is safe :)", "error");
      }

      });

}


function clearForm(data) {
$(data).trigger("reset");
}

 </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nextzen\resources\views/admin/processWorkflow/processWorkflowView.blade.php ENDPATH**/ ?>