<footer class="footer">
    <div class="footer__block block no-margin-bottom">
        <div class="container-fluid text-center">
            <p class="no-margin-bottom">2020 &copy; Mridul Hossain</p>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\nextzen\resources\views/layouts/backend/partial/footer.blade.php ENDPATH**/ ?>