<?php

// add next training route
Route::get('addNextTraining', 'nextTraining\NextTrainingController@addNextTraining');